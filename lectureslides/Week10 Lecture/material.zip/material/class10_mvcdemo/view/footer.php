<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> My Guitar Shop, Inc. Hello
    </p>
</footer>
</body>
</html>

