// script.js

// Array of words to select from
const wordOptions = [
    "java",
    "javascript",
    "python",
    "pascal",
    "ruby",
    "perl",
    "swift",
    "kotlin",
  ];
  
  // Randomly selecting a word from the array
  let chosenIndex = Math.floor(Math.random() * wordOptions.length);
  let chosenWord = wordOptions[chosenIndex];
  console.log(chosenWord); // Logging the chosen word for debugging purposes.
  
  // Array to keep track of guessed letters
  let guessedLetters = [];
  
  // Initial number of guesses allowed
  const maxGuesses = 6;
  let remainingGuesses = maxGuesses;
  
  // Initial display of the word with underscores
  let initialDisplay = "";
  for (let char of chosenWord) {
    initialDisplay += "_ ";
  }
  document.getElementById("displayWord").textContent = initialDisplay;
  document.getElementById("remainingGuesses").textContent = `Remaining guesses: ${remainingGuesses}`;
  
  // Function to handle the letter guessing
  function checkGuess() {
    let inputField = document.getElementById("letter-input");
  
    // Check for empty input
    if (!inputField.value) {
      alert("Please enter a letter.");
      return;
    }
  
    // Convert the guessed letter to lowercase to ensure case-insensitivity.
    let guessedLetter = inputField.value.toLowerCase();
  
    // Clear the input field
    inputField.value = "";
  
    // Check if the letter has already been guessed
    if (guessedLetters.includes(guessedLetter)) {
      alert("You already guessed that letter!");
      return;
    }
  
    // Add the guessed letter to the array
    guessedLetters.push(guessedLetter);
  
    // Update the displayed word with the guessed letters
    let newDisplay = "";
    let isWordGuessed = true;
    for (let char of chosenWord) {
      if (guessedLetters.includes(char)) {
        newDisplay += char + " ";
      } else {
        newDisplay += "_ ";
        isWordGuessed = false;
      }
    }
    document.getElementById("displayWord").textContent = newDisplay;
  
    // Check if the guessed letter is not in the chosen word
    if (!chosenWord.includes(guessedLetter)) {
      remainingGuesses--;
      document.getElementById("remainingGuesses").textContent = `Remaining guesses: ${remainingGuesses}`;
  
      // Provide a hint when half of the guesses are used
      if (remainingGuesses === Math.floor(maxGuesses / 2)) {
        let hintIndex;
        do {
          hintIndex = Math.floor(Math.random() * chosenWord.length);
        } while (guessedLetters.includes(chosenWord[hintIndex]));
        
        alert(`Hint: One of the characters is '${chosenWord[hintIndex]}'`);
        guessedLetters.push(chosenWord[hintIndex]);
  
        // Update the displayed word with the hint
        newDisplay = "";
        for (let char of chosenWord) {
          if (guessedLetters.includes(char)) {
            newDisplay += char + " ";
          } else {
            newDisplay += "_ ";
          }
        }
        document.getElementById("displayWord").textContent = newDisplay;
      }
    }
  
    // Check if the entire word has been guessed
    if (isWordGuessed) {
      alert("Congratulations! You've guessed the word!");
    } else if (remainingGuesses === 0) {
      alert(`Game over! The word was: ${chosenWord}`);
      // Reset the game
      resetGame();
    }
  }
  
  // Function to reset the game
  function resetGame() {
    chosenIndex = Math.floor(Math.random() * wordOptions.length);
    chosenWord = wordOptions[chosenIndex];
    guessedLetters = [];
    remainingGuesses = maxGuesses;
    initialDisplay = "";
    for (let char of chosenWord) {
      initialDisplay += "_ ";
    }
    document.getElementById("displayWord").textContent = initialDisplay;
    document.getElementById("remainingGuesses").textContent = `Remaining guesses: ${remainingGuesses}`;
  }
  